document.getElementById("open").addEventListener("click", async () => {
  const status = document.getElementById("status");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("没有找到当前标签页");
    await chrome.tabs.sendMessage(tab.id, { type: "OPEN_FLOATING_PANEL" });
    status.textContent = "悬浮面板已打开。";
  } catch (e) {
    status.textContent = "当前页面不受支持，或尚未刷新页面。请在 Flow、豆包、千问或 Grok 页面重试。";
  }
});
