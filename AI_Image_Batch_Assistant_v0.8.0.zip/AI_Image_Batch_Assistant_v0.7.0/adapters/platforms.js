(() => {
  const common = { input: '', send: '', image: '', uploadButton: '', fileInput: '' };
  window.AIBA_PLATFORMS = {
    flow: { id:'flow', label:'Google Flow', hosts:['flow.google.com','labs.google'], folder:'Flow', input:'div.ProseMirror[role="textbox"][contenteditable="true"]', send:'flow-generate-icon-button button[aria-label="Start generation"]', ...common },
    doubao: { id:'doubao', label:'豆包', hosts:['www.doubao.com','doubao.com'], folder:'Doubao', ...common },
    qwen: { id:'qwen', label:'千问国际版', hosts:['chat.qwen.ai'], folder:'Qwen', ...common },
    qianwen_cn: { id:'qianwen_cn', label:'千问国内版', hosts:['www.qianwen.com','qianwen.com'], folder:'Qianwen_CN', ...common },
    grok: { id:'grok', label:'Grok', hosts:['grok.com'], folder:'Grok', ...common }
  };
})();
