(() => {
  window.AIBA_IMPORT = {
    basename(path) { return String(path || '').replace(/\\/g, '/').split('/').pop().trim().toLowerCase(); },
    async readXlsxFirstSheet(buffer) {
      const bytes = new Uint8Array(buffer), view = new DataView(buffer); let end = -1;
      for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
        if (view.getUint32(i, true) === 0x06054b50) { end = i; break; }
      }
      if (end < 0) throw new Error('不是有效的 XLSX 文件');
      const count = view.getUint16(end + 10, true), central = view.getUint32(end + 16, true), entries = {}; let p = central;
      for (let n = 0; n < count; n++) {
        if (view.getUint32(p, true) !== 0x02014b50) break;
        const method=view.getUint16(p+10,true), size=view.getUint32(p+20,true), nl=view.getUint16(p+28,true), el=view.getUint16(p+30,true), cl=view.getUint16(p+32,true), local=view.getUint32(p+42,true);
        const name=new TextDecoder().decode(bytes.slice(p+46,p+46+nl)); entries[name]={method,size,local}; p+=46+nl+el+cl;
      }
      async function readEntry(name) {
        const x=entries[name]; if(!x) return null; const q=x.local, nl=view.getUint16(q+26,true), el=view.getUint16(q+28,true), data=bytes.slice(q+30+nl+el,q+30+nl+el+x.size);
        if(x.method===0) return new TextDecoder().decode(data);
        if(x.method!==8) throw new Error('XLSX 使用了不支持的压缩方式');
        return await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
      }
      const sharedXml=await readEntry('xl/sharedStrings.xml');
      const shared=sharedXml ? [...new DOMParser().parseFromString(sharedXml,'application/xml').getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(t=>t.textContent).join('')) : [];
      const sheetName=Object.keys(entries).filter(x=>/^xl\/worksheets\/sheet\d+\.xml$/.test(x)).sort()[0];
      if(!sheetName) throw new Error('XLSX 中没有可读取的工作表');
      const xml=new DOMParser().parseFromString(await readEntry(sheetName),'application/xml');
      const rows=[];
      for(const row of [...xml.getElementsByTagName('row')]) {
        const values={};
        for(const cell of [...row.getElementsByTagName('c')]) {
          const ref=cell.getAttribute('r')||'', col=(ref.match(/^[A-Z]+/)||[])[0]; if(!col) continue;
          const v=cell.getElementsByTagName('v')[0]?.textContent ?? '';
          let value=cell.getAttribute('t')==='s' ? (shared[Number(v)]||'') : cell.getAttribute('t')==='inlineStr' ? [...cell.getElementsByTagName('t')].map(t=>t.textContent).join('') : v;
          values[col]=String(value).trim();
        }
        if(Object.keys(values).length) rows.push({row:Number((row.getAttribute('r')||'0')), A:values.A||'', B:values.B||'', values});
      }
      return rows;
    }
  };
})();
