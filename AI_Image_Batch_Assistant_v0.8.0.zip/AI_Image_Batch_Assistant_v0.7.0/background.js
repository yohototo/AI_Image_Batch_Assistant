function sendDebuggerCommand(target, method, params = {}) {
  return new Promise((resolve, reject) => chrome.debugger.sendCommand(target, method, params, result => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(result);
  }));
}
function attachDebugger(target) {
  return new Promise((resolve, reject) => chrome.debugger.attach(target, "1.3", () => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve();
  }));
}
function detachDebugger(target) { return new Promise(resolve => chrome.debugger.detach(target, () => resolve())); }
const safeName = s => String(s || "image").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/[. ]+$/g, "").slice(0, 110) || "image";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "TRUSTED_REPLACE_TEXT" || msg.type === "TRUSTED_CLICK") {
    const tabId = sender.tab?.id;
    if (tabId == null) { sendResponse({ ok: false, error: "无法识别当前标签页" }); return; }
    const target = { tabId };
    (async () => {
      let attached = false;
      try {
        await attachDebugger(target); attached = true;
        if (msg.type === "TRUSTED_REPLACE_TEXT") {
          await sendDebuggerCommand(target, "Input.dispatchKeyEvent", { type: "keyDown", key: "Control", code: "ControlLeft", modifiers: 2 });
          await sendDebuggerCommand(target, "Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2 });
          await sendDebuggerCommand(target, "Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65, modifiers: 2 });
          await sendDebuggerCommand(target, "Input.dispatchKeyEvent", { type: "keyUp", key: "Control", code: "ControlLeft" });
          await sendDebuggerCommand(target, "Input.insertText", { text: String(msg.text ?? "") });
        } else {
          await sendDebuggerCommand(target, "Input.dispatchMouseEvent", { type: "mouseMoved", x: msg.x, y: msg.y });
          await sendDebuggerCommand(target, "Input.dispatchMouseEvent", { type: "mousePressed", x: msg.x, y: msg.y, button: "left", clickCount: 1 });
          await sendDebuggerCommand(target, "Input.dispatchMouseEvent", { type: "mouseReleased", x: msg.x, y: msg.y, button: "left", clickCount: 1 });
        }
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, error: e.message }); }
      finally { if (attached) await detachDebugger(target); }
    })();
    return true;
  }
  if (msg.type === "DOWNLOAD_IMAGE" && msg.url) {
    if (!/^https?:\/\//i.test(msg.url)) { sendResponse?.({ ok: false, error: "仅允许下载正常提供的 HTTP/HTTPS 图片资源" }); return; }
    const platform = safeName(msg.platform || "Other");
    const rawName = safeName(msg.filename || "image");
    const filename = `${platform}/${rawName.includes(".") ? rawName : rawName + (msg.extension || ".png")}`;
    chrome.downloads.download({ url: msg.url, filename, conflictAction: "uniquify", saveAs: false }, id => {
      if (chrome.runtime.lastError) {
        const error = chrome.runtime.lastError.message;
        sendResponse({ ok: false, error, filename });
        chrome.runtime.sendMessage({ type: "DOWNLOAD_RESULT", ok: false, error, filename }).catch(() => {});
      } else {
        sendResponse({ ok: true, filename, downloadId: id });
        chrome.runtime.sendMessage({ type: "DOWNLOAD_RESULT", ok: true, filename, downloadId: id }).catch(() => {});
      }
    });
    return true;
  }
  if (msg.type === "SAVE_STATUS") chrome.storage.local.set({ lastStatus: msg.message, lastStatusAt: Date.now() });
});
