(() => {
  if (window.__aiImageBatchAssistantLoaded) return;
  window.__aiImageBatchAssistantLoaded = true;

  const PLATFORMS = window.AIBA_PLATFORMS || {};
  const host = location.hostname;
  const currentPlatform = Object.keys(PLATFORMS).find(k => PLATFORMS[k].hosts.some(h => host === h || host.endsWith("." + h)));
  if (!currentPlatform) return;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const safeName = s => String(s || "image").split(/[,，]/)[0].trim().replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/[. ]+$/g, "").slice(0, 100) || "image";
  let hostEl = null, shadow = null, statusEl = null, running = false, paused = false, stopRequested = false;
  let completed = 0, total = 0, pickerActive = false, activePlatform = currentPlatform, draggedLauncher = false;
  let selectedImageFiles = [], advancedRows = [], taskMode = "text";
  const TASK_DB = "AIBA_TASK_DB", TASK_STORE = "state";
  function openTaskDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(TASK_DB, 1);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(TASK_STORE)) req.result.createObjectStore(TASK_STORE); };
      req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
    });
  }
  async function taskDB(op, value) {
    const db = await openTaskDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TASK_STORE, "readwrite"), store = tx.objectStore(TASK_STORE);
      const req = op === "put" ? store.put(value, "pending") : op === "delete" ? store.delete("pending") : store.get("pending");
      req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
      tx.oncomplete = () => db.close(); tx.onerror = () => reject(tx.error);
    });
  }
  const savePending = data => taskDB("put", { ...data, savedAt: Date.now() }).catch(e => { console.warn("AIBA task persistence failed", e); status(`任务持久化失败：${e.message}。刷新页面后可能无法恢复，请勿刷新。`); });
  const readPending = () => taskDB("get").catch(() => null);
  const clearPending = () => taskDB("delete").catch(() => {});

  const defaults = () => ({ inputSelector: PLATFORMS[currentPlatform].input, sendSelector: PLATFORMS[currentPlatform].send, imageSelector: "" });
  const getPlatformSettings = async key => {
    const all = await chrome.storage.local.get("platformSettings");
    return { ...defaultsFor(key), ...(all.platformSettings?.[key] || {}) };
  };
  const defaultsFor = key => ({ inputSelector: PLATFORMS[key].input || "", sendSelector: PLATFORMS[key].send || "", imageSelector: PLATFORMS[key].image || "", uploadButtonSelector: PLATFORMS[key].uploadButton || "", fileInputSelector: PLATFORMS[key].fileInput || "" });
  const updatePlatformSettings = async (key, data) => {
    const all = await chrome.storage.local.get("platformSettings");
    const platformSettings = all.platformSettings || {};
    platformSettings[key] = { ...(platformSettings[key] || defaultsFor(key)), ...data };
    await chrome.storage.local.set({ platformSettings });
  };
  const status = message => {
    if (statusEl) statusEl.textContent = message;
    chrome.runtime.sendMessage({ type: "SAVE_STATUS", message }).catch(() => {});
  };
  const waitIfPaused = async () => {
    while (paused && !stopRequested) await sleep(200);
    return !stopRequested;
  };
  const pausableDelay = async ms => {
    let left = ms;
    while (left > 0 && !stopRequested) {
      if (!(await waitIfPaused())) break;
      const step = Math.min(250, left);
      await sleep(step);
      if (!paused) left -= step;
    }
  };
  const progress = () => {
    if (!shadow) return;
    const ring = shadow.querySelector(".progress-ring");
    const fill = shadow.querySelector(".progress-fill");
    const current = shadow.querySelector(".progress-current");
    if (!ring || !fill || !current) return;
    ring.style.display = running && total > 0 ? "block" : "none";
    const circumference = 2 * Math.PI * 24;
    const unit = circumference / Math.max(1, total);
    fill.style.strokeDasharray = `${circumference * (total ? completed / total : 0)} ${circumference}`;
    current.style.strokeDasharray = `${running && completed < total ? unit : 0} ${circumference}`;
    current.style.strokeDashoffset = `${-unit * completed}`;
    current.style.stroke = paused ? "#16a34a" : "#dc2626";
    shadow.querySelector(".launcher").title = total ? `${completed}/${total} · ${paused ? "已暂停" : "任务运行中"}` : "打开批量生图面板";
  };

  function pickElement(which) {
    if (pickerActive) return;
    pickerActive = true;
    const note = document.createElement("div");
    note.textContent = `请点击${which === "inputSelector" ? "提示词输入框" : which === "sendSelector" ? "发送/生成按钮" : which === "uploadButtonSelector" ? "图片上传按钮" : which === "fileInputSelector" ? "文件输入控件" : "生成图片"}，按 Esc 取消`;
    Object.assign(note.style, { position: "fixed", top: "12px", left: "50%", transform: "translateX(-50%)", zIndex: "2147483647", background: "#202124", color: "white", padding: "11px 16px", borderRadius: "8px", font: "13px Arial", pointerEvents: "none" });
    document.documentElement.appendChild(note);
    const clean = () => { note.remove(); document.removeEventListener("click", onClick, true); document.removeEventListener("keydown", onKey, true); pickerActive = false; };
    const onKey = e => { if (e.key === "Escape") clean(); };
    const onClick = e => {
      if (hostEl && (e.target === hostEl || hostEl.contains(e.target))) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      let el = e.target;
      if (which === "inputSelector") el = el.closest('[contenteditable="true"],textarea,input,[role="textbox"]') || el;
      else if (which === "sendSelector" || which === "uploadButtonSelector") el = el.closest("button,[role=button]") || el;
      else if (which === "fileInputSelector") el = el.closest('input[type="file"]') || el;
      else el = el.closest("img") || el;
      const selector = selectorFor(el);
      clean();
      const field = which === "imageSelector" ? "imageSelector" : which;
      const input = shadow?.getElementById(field);
      if (input) input.value = selector;
      const data = {}; data[field] = selector; updatePlatformSettings(activePlatform, data);
      status(`已选取${field === "inputSelector" ? "输入框" : field === "sendSelector" ? "发送按钮" : field === "uploadButtonSelector" ? "上传按钮" : field === "fileInputSelector" ? "文件输入控件" : "图片"}：${selector}`);
    };
    document.addEventListener("click", onClick, true); document.addEventListener("keydown", onKey, true);
  }
  function selectorFor(el) {
    if (!el || el.nodeType !== 1) return "";
    if (el.id) return `#${CSS.escape(el.id)}`;
    for (const attr of ["data-testid", "placeholder", "aria-label", "name"]) {
      const v = el.getAttribute(attr);
      if (v) return `${el.tagName.toLowerCase()}[${attr}="${String(v).replace(/"/g, '\\"')}"]`;
    }
    if (el.getAttribute("role") === "textbox") return `${el.tagName.toLowerCase()}[role="textbox"]`;
    if (el.isContentEditable) return `${el.tagName.toLowerCase()}[contenteditable="true"]`;
    const parts = []; let node = el;
    while (node && node.nodeType === 1 && node !== document.body && parts.length < 4) {
      let part = node.tagName.toLowerCase();
      if (node.parentElement) {
        const siblings = [...node.parentElement.children].filter(x => x.tagName === node.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      parts.unshift(part); node = node.parentElement;
    }
    return parts.join(" > ");
  }
  function findInput(selector) {
    let el = null;
    try { if (selector) el = document.querySelector(selector); } catch (_) {}
    const editable = 'textarea,input:not([type]),input[type="text"],[contenteditable="true"],[role="textbox"],[data-lexical-editor="true"],.ProseMirror';
    if (el && !el.matches(editable)) el = el.querySelector(editable) || el;
    if (el && el.getClientRects().length && !el.closest("#ai-image-batch-floating-host")) return el;
    const candidates = [...document.querySelectorAll(editable)]
      .filter(x => x.getClientRects().length && !x.closest("#ai-image-batch-floating-host") && !x.disabled && x.getAttribute("aria-hidden") !== "true")
      .filter(x => { const r=x.getBoundingClientRect(); return r.width>80 && r.height>18; });
    const score = x => {
      const r=x.getBoundingClientRect(), hint=`${x.getAttribute("placeholder")||""} ${x.getAttribute("aria-label")||""} ${x.getAttribute("data-testid")||""} ${x.className||""}`;
      return r.width*r.height + (/prompt|message|输入|提示词|composer|editor/i.test(hint)?1000000:0) + (x.isContentEditable?50000:0);
    };
    return candidates.sort((a,b)=>score(b)-score(a))[0] || null;
  }
  const area = el => { const r = el.getBoundingClientRect(); return r.width * r.height; };
  function findSend(selector, input) {
    let el = null;
    try { if (selector) el = document.querySelector(selector); } catch (_) {}
    if (el && !el.matches("button,[role=button]")) el = el.closest("button,[role=button]") || el.querySelector("button,[role=button]") || el;
    if (el && isUsableButton(el)) return el;
    const scope = input?.parentElement?.parentElement?.parentElement || document;
    let buttons = [...scope.querySelectorAll('button,[role="button"]')].filter(isUsableButton);
    if (!buttons.length) buttons = [...document.querySelectorAll('button,[role="button"]')].filter(isUsableButton);
    const matching = buttons.filter(b => /send|submit|generate|create|发送|生成|创建|提交/i.test(`${b.getAttribute("aria-label") || ""} ${b.getAttribute("title") || ""} ${b.innerText || ""}`));
    return matching[matching.length - 1] || buttons[buttons.length - 1] || null;
  }
  function isUsableButton(el) {
    if (!el || !el.getClientRects().length || el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    if (hostEl && hostEl.contains(el)) return false;
    const r = el.getBoundingClientRect(); return r.width > 8 && r.height > 8;
  }
  function imageSources(selector) {
    let imgs = [];
    try { imgs = selector ? [...document.querySelectorAll(selector)] : [...document.images]; } catch (_) { imgs = [...document.images]; }
    return imgs.filter(im => {
      const r = im.getBoundingClientRect();
      return r.width >= 160 && r.height >= 120 && im.getClientRects().length;
    }).map(im => ({ url: im.currentSrc || im.src, w: im.naturalWidth, h: im.naturalHeight })).filter(x => x.url && /^https?:\/\//i.test(x.url));
  }
  function askBackground(type, data) {
    return new Promise(resolve => chrome.runtime.sendMessage({ type, ...data }, res => resolve(res || { ok: false, error: chrome.runtime.lastError?.message || "后台无响应" })));
  }
  async function clickElement(button) {
    const r = button.getBoundingClientRect();
    return askBackground("TRUSTED_CLICK", { x: r.left + r.width / 2, y: r.top + r.height / 2 });
  }
  async function runBatch(prompts, cfg, shared, startIndex = 0, restoring = false) {
    if (running) { status("已有任务正在运行，请勿重复启动。"); return; }
    if (!prompts.length) { status("请先输入或导入提示词。"); return; }
    running = true; paused = false; stopRequested = false; completed = startIndex; total = prompts.length; progress();
    await savePending({ kind:"text", platform:currentPlatform, tasks:prompts, completed, cfg, shared });
    const minDelay = Math.max(1, Number(shared.minDelay) || 12), maxDelay = Math.max(minDelay, Number(shared.maxDelay) || 25);
    const groupN = Math.max(0, Number(shared.groupN) || 0), restMin = Math.max(0, Number(shared.restMin) || 30), restMax = Math.max(restMin, Number(shared.restMax) || 60);
    const timeout = Math.max(20, Number(shared.imageTimeout) || 120);
    try {
      for (let i = startIndex; i < prompts.length; i++) {
        if (!(await waitIfPaused())) break;
        const input = findInput(cfg.inputSelector);
        if (!input) throw new Error("找不到提示词输入框。请点击“选取输入框”手动指定。");
        input.focus();
        const typed = await askBackground("TRUSTED_REPLACE_TEXT", { text: prompts[i] });
        if (!typed.ok) throw new Error(`输入失败：${typed.error}。请关闭 DevTools 后重试。`);
        await pausableDelay(500);
        const button = findSend(cfg.sendSelector, input);
        if (!button) throw new Error("找不到发送/生成按钮。请点击“选取发送按钮”手动指定。");
        const before = new Set(imageSources(cfg.imageSelector).map(x => x.url));
        const clicked = await clickElement(button);
        if (!clicked.ok) throw new Error(`点击发送按钮失败：${clicked.error}`);
        status(`已发送第 ${i + 1}/${prompts.length} 条，正在等待新图片……`);
        let newImages = [];
        for (let sec = 0; sec < timeout && !stopRequested; sec++) {
          if (!(await waitIfPaused())) break;
          newImages = imageSources(cfg.imageSelector).filter(x => !before.has(x.url));
          if (newImages.length) break;
          await pausableDelay(1000);
        }
        if (newImages.length) {
          const webDownload = (await chrome.storage.local.get("webDownloadEnabled")).webDownloadEnabled === true;
          if (webDownload) for (let j = 0; j < newImages.length; j++) {
            const ext = /\.jpe?g([?#]|$)/i.test(newImages[j].url) ? ".jpg" : ".png";
            await askBackground("DOWNLOAD_IMAGE", { url: newImages[j].url, filename: `${safeName(prompts[i])}${newImages.length > 1 ? `_${j + 1}` : ""}${ext}`, platform: PLATFORMS[currentPlatform].folder, extension: "" });
          }
          status(`第 ${i + 1}/${prompts.length} 条：检测到 ${newImages.length} 张新图片。${webDownload ? "已提交网页下载。" : "网页下载功能已关闭。"}`);
        } else {
          status(`第 ${i + 1}/${prompts.length} 条：已发送，但在 ${timeout} 秒内未检测到新图片。请检查网页结果；需要下载时可在设置中开启网页下载。`);
        }
        completed = i + 1; progress();
        await savePending({ kind:"text", platform:currentPlatform, tasks:prompts, completed, cfg, shared });
        if (i < prompts.length - 1) {
          const delay = (minDelay + Math.random() * (maxDelay - minDelay)) * 1000;
          status(`第 ${i + 1} 条完成，等待 ${(delay / 1000).toFixed(1)} 秒后继续。`);
          await pausableDelay(delay);
        }
        if (groupN > 0 && completed < prompts.length && completed % groupN === 0) {
          const rest = Math.floor(restMin + Math.random() * (restMax - restMin + 1));
          status(`已完成 ${completed} 条，进入批次休息：${rest} 秒。`);
          await pausableDelay(rest * 1000);
        }
      }
      status(stopRequested ? `任务已停止，完成 ${completed}/${total} 条。` : `批量任务结束，完成 ${completed}/${total} 条。`);
      if (!stopRequested && completed >= total) await clearPending();
      if (stopRequested) await clearPending();
    } catch (e) { status(`任务出错：${e.message}（已完成 ${completed}/${total} 条）`); }
    finally { running = false; paused = false; stopRequested = false; progress(); }
  }

  function dispatchFileDrop(target, file) {
    if (!target) return false;
    const dt = new DataTransfer(); dt.items.add(file);
    const opts = { bubbles:true, cancelable:true, composed:true, dataTransfer:dt };
    for (const type of ["dragenter", "dragover", "drop"]) {
      const event = new DragEvent(type, opts);
      target.dispatchEvent(event);
    }
    return true;
  }
  async function uploadImageFile(file, cfg) {
    // Flow and Qwen expose a page-level drag/drop path; their + menu and file input
    // are transient, so selecting them with a CSS picker is inherently unreliable.
    const useDrop = ["flow", "qwen", "qianwen_cn"].includes(currentPlatform);
    if (useDrop) {
      let target = null;
      try { if (cfg.uploadButtonSelector) target = document.querySelector(cfg.uploadButtonSelector); } catch (_) {}
      if (target && target.parentElement) target = target.parentElement;
      if (!target) {
        const editor = findInput(cfg.inputSelector);
        target = editor?.closest("form") || editor?.parentElement?.parentElement || document.body;
      }
      dispatchFileDrop(target, file);
      await sleep(1400);
      return;
    }
    let input = null;
    try { if (cfg.fileInputSelector) input = document.querySelector(cfg.fileInputSelector); } catch (_) {}
    if (!input && cfg.uploadButtonSelector) {
      let uploadButton = null;
      try { uploadButton = document.querySelector(cfg.uploadButtonSelector); } catch (_) {}
      if (uploadButton) { await clickElement(uploadButton); await sleep(700); }
    }
    if (!input) input = document.querySelector('input[type="file"][accept*="image"],input[type="file"]');
    if (!input || input.type !== 'file') throw new Error('找不到图片文件输入控件。该平台未启用拖放上传，请先打开上传入口再配置文件控件。');
    const transfer = new DataTransfer(); transfer.items.add(file); input.files = transfer.files;
    input.dispatchEvent(new Event('input', { bubbles:true })); input.dispatchEvent(new Event('change', { bubbles:true }));
    await sleep(900);
  }
  async function runImageBatch(tasks, cfg, shared, startIndex = 0, restoring = false) {
    if (running) { status('已有任务正在运行，请勿重复启动。'); return; }
    if (!tasks.length) { status('没有可执行的图生图任务。'); return; }
    running=true; paused=false; stopRequested=false; completed=startIndex; total=tasks.length; progress();
    await savePending({ kind:"image", platform:currentPlatform, tasks, completed, cfg, shared });
    const minDelay=Math.max(1,Number(shared.minDelay)||12), maxDelay=Math.max(minDelay,Number(shared.maxDelay)||25);
    const groupN=Math.max(0,Number(shared.groupN)||0), restMin=Math.max(0,Number(shared.restMin)||30), restMax=Math.max(restMin,Number(shared.restMax)||60), timeout=Math.max(20,Number(shared.imageTimeout)||120);
    try {
      for(let i=startIndex;i<tasks.length;i++) {
        if(!(await waitIfPaused())) break;
        const task=tasks[i]; status(`图生图 ${i+1}/${tasks.length}：正在上传 ${task.file.name}`);
        await uploadImageFile(task.file,cfg);
        if(!(await waitIfPaused())) break;
        const input=findInput(cfg.inputSelector); if(!input) throw new Error('找不到提示词输入框，请先配置输入框选择器。');
        input.focus(); const typed=await askBackground('TRUSTED_REPLACE_TEXT',{text:task.prompt});
        if(!typed.ok) throw new Error(`输入提示词失败：${typed.error}`);
        await pausableDelay(500);
        const button=findSend(cfg.sendSelector,input); if(!button) throw new Error('找不到生成按钮，请先配置生成按钮选择器。');
        const before=new Set(imageSources(cfg.imageSelector).map(x=>x.url));
        const clicked=await clickElement(button); if(!clicked.ok) throw new Error(`点击生成按钮失败：${clicked.error}`);
        status(`图生图 ${i+1}/${tasks.length} 已提交，等待结果……`);
        let found=[];
        for(let sec=0;sec<timeout&&!stopRequested;sec++) {
          if(!(await waitIfPaused())) break;
          found=imageSources(cfg.imageSelector).filter(x=>!before.has(x.url)); if(found.length) break;
          await pausableDelay(1000);
        }
        if(found.length) {
          const webDownload = (await chrome.storage.local.get("webDownloadEnabled")).webDownloadEnabled === true;
          if (webDownload) for(let j=0;j<found.length;j++) {
            const ext=/\.jpe?g([?#]|$)/i.test(found[j].url)?'.jpg':'.png';
            await askBackground('DOWNLOAD_IMAGE',{url:found[j].url,filename:`${safeName(task.prompt)}_${i+1}${found.length>1?'_'+(j+1):''}${ext}`,platform:PLATFORMS[currentPlatform].folder,extension:''});
          }
          status(`图生图 ${i+1}/${tasks.length}：检测到 ${found.length} 张结果图片。${webDownload ? "已提交网页下载。" : "网页下载功能已关闭。"}`);
        } else status(`图生图 ${i+1}/${tasks.length}：已提交，但未能在 ${timeout} 秒内确认新图片；请检查网页结果。`);
        completed=i+1; progress();
        await savePending({ kind:"image", platform:currentPlatform, tasks, completed, cfg, shared });
        if(i<tasks.length-1) await pausableDelay((minDelay+Math.random()*(maxDelay-minDelay))*1000);
        if(groupN>0&&completed<tasks.length&&completed%groupN===0) await pausableDelay(Math.floor(restMin+Math.random()*(restMax-restMin+1))*1000);
      }
      status(stopRequested?`图生图已停止，完成 ${completed}/${total} 条。`:`图生图队列结束，完成 ${completed}/${total} 条。`);
      if (!stopRequested && completed >= total) await clearPending();
      if (stopRequested) await clearPending();
    } catch(e) { status(`图生图任务出错：${e.message}（完成 ${completed}/${total}）`); }
    finally { running=false; paused=false; stopRequested=false; progress(); }
  }

  function createPanel() {
    if (hostEl?.isConnected) return;
    hostEl = document.createElement("div"); hostEl.id = "ai-image-batch-floating-host";
    Object.assign(hostEl.style, { position: "fixed", right: "22px", bottom: "22px", zIndex: "2147483646" });
    shadow = hostEl.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box} :host{all:initial;font-family:Arial,"Microsoft YaHei",sans-serif;color:#202124}
        .launcher-wrap{position:relative;width:64px;height:64px;cursor:grab;touch-action:none}.launcher{position:absolute;inset:7px;width:50px;height:50px;border:0;border-radius:50%;background:#facc15;box-shadow:0 3px 14px #0004;cursor:pointer;padding:0}
        .progress-ring{position:absolute;inset:0;width:64px;height:64px;transform:rotate(-90deg);pointer-events:none;display:none}.progress-track{fill:none;stroke:#a1a1aa;stroke-width:4}.progress-fill{fill:none;stroke:#16a34a;stroke-width:4;stroke-linecap:round}.progress-current{fill:none;stroke:#dc2626;stroke-width:4;stroke-linecap:round}
        .panel{display:none;width:410px;max-height:min(84vh,820px);background:#fff;border:1px solid #d1d5db;border-radius:13px;box-shadow:0 9px 36px #0004;overflow:hidden}.panel.open{display:flex;flex-direction:column}
        .head{display:flex;justify-content:space-between;align-items:center;padding:11px 13px;background:#202124;color:white;cursor:move;user-select:none}.head strong{font-size:14px}.head button{border:0;background:#ffffff20;color:white;border-radius:5px;padding:4px 8px;cursor:pointer}
        .body{padding:12px;overflow:auto;font-size:12px}.tabs{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px}.tab{border:1px solid #d1d5db;background:#f8fafc;color:#374151;border-radius:6px;padding:6px 10px;cursor:pointer}.tab.active{background:#dbeafe;border-color:#60a5fa;color:#1d4ed8;font-weight:700}
        label{display:block;font-weight:600;margin:9px 0 4px}textarea,input{font:12px Arial;width:100%;border:1px solid #d1d5db;border-radius:6px;padding:8px;color:#202124;background:white}textarea{height:105px;resize:vertical;line-height:1.45}.row{display:flex;gap:8px}.row>div{flex:1;min-width:0}.hint{display:block;color:#6b7280;font-size:11px;line-height:1.4;margin-top:4px}
        .actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:11px}.modebar{display:flex;gap:5px;margin:8px 0}.modebar button{flex:1;border:1px solid #cbd5e1;background:#f8fafc;border-radius:6px;padding:7px 4px;font-size:11px;cursor:pointer}.modebar button.active{background:#dbeafe;border-color:#60a5fa;color:#1d4ed8;font-weight:700}.dropzone{border:1px dashed #94a3b8;border-radius:7px;padding:12px;text-align:center;color:#475569;background:#f8fafc;margin-top:7px}.dropzone.drag{background:#dbeafe;border-color:#2563eb}.mode-note{font-size:11px;color:#64748b;margin:4px 0}button.action{border:0;border-radius:6px;padding:8px 10px;background:#2563eb;color:white;cursor:pointer;font-size:12px}button.secondary{background:#64748b}button.stop{background:#b91c1c}button.pause{background:#d97706}.status{white-space:pre-wrap;overflow-wrap:anywhere;background:#f1f5f9;border-radius:6px;padding:8px;margin-top:10px;min-height:36px;line-height:1.45}.file{margin-top:4px}.foot{color:#6b7280;font-size:10px;margin-top:8px}.section{border-top:1px solid #e5e7eb;margin-top:12px;padding-top:7px}.section-title{font-weight:700;color:#374151;margin-top:2px}.platform-note{font-size:11px;color:#64748b;margin:5px 0}
      </style>
      <div class="launcher-wrap" title="拖动头像移动位置，点击打开面板">
        <svg class="progress-ring" viewBox="0 0 64 64"><circle class="progress-track" cx="32" cy="32" r="24"/><circle class="progress-fill" cx="32" cy="32" r="24"/><circle class="progress-current" cx="32" cy="32" r="24"/></svg>
        <button class="launcher" aria-label="打开批量生图面板"><svg viewBox="0 0 50 50" width="50" height="50"><circle cx="25" cy="25" r="23" fill="#facc15"/><path d="M11 19Q17 11 22 19M28 19Q34 11 39 19" fill="none" stroke="#292524" stroke-width="2.5" stroke-linecap="round"/><circle cx="17" cy="25" r="3.7" fill="#ef4444"/><circle cx="33" cy="25" r="3.7" fill="#ef4444"/><ellipse cx="25" cy="29" rx="4" ry="4.5" fill="#ef4444"/><path d="M13 34Q25 47 37 34Q25 39 13 34" fill="#fff" stroke="#292524" stroke-width="1.6"/></svg></button>
      </div>
      <section class="panel"><header class="head"><strong>AI Image Batch Assistant · v0.7.0</strong><div><button class="min">收起</button></div></header>
      <div class="body">
        <div class="tabs">${Object.entries(PLATFORMS).map(([k,v])=>`<button class="tab" data-platform="${k}">${v.label}</button>`).join("")}</div>
        <div class="platform-note" id="platformNote"></div>
        <div class="modebar"><button data-mode="text" class="active">文生图</button><button data-mode="simple">简易图生图</button><button data-mode="advanced">高级图生图</button></div>
        <div class="mode-note" id="modeNote">文生图：每行一条提示词，支持 | 分隔。</div>
        <div id="textMode"><label>提示词列表（| 分隔或每行一条）</label><textarea id="prompts" placeholder="每行输入一条提示词"></textarea><label>导入提示词文件（TXT / XLSX，第一张表 A 列）</label><input class="file" id="file" type="file" accept=".txt,.xlsx"></div>
        <div id="imageMode" style="display:none"><label>统一图生图提示词（简易版所有图片共用）</label><textarea id="imagePrompt" placeholder="输入所有参考图片共用的提示词"></textarea><label>选择或拖入多张参考图片</label><input class="file" id="imageFiles" type="file" accept="image/*" multiple><div class="dropzone" id="dropzone">将多张图片拖放到这里，或使用上方选择文件</div><div class="mode-note" id="imageCount">尚未选择图片</div></div>
        <div id="advancedMode" style="display:none"><label>高级图生图 Excel（A列图片路径，B列专属提示词）</label><input class="file" id="advancedXlsx" type="file" accept=".xlsx"><label>选择 Excel 对应的本地图片（支持多选）</label><input class="file" id="advancedFiles" type="file" accept="image/*" multiple><div class="mode-note" id="advancedNote">导入后按文件名匹配 Excel A 列路径。浏览器不能仅凭表格中的绝对路径读取本地文件；需要用户在此授权选择图片。</div></div>
        <div class="section"><div class="section-title">当前平台设置（各平台独立保存）</div>
          <label>文本框 CSS 选择器</label><input id="inputSelector" placeholder="自动识别，也可手动选取"><button class="action secondary" id="pickInput">选取文本框</button>
          <label>发送按钮 CSS 选择器</label><input id="sendSelector" placeholder="自动识别，也可手动选取"><button class="action secondary" id="pickSend">选取发送按钮</button>
          <label>图片 CSS 选择器（可选，留空自动检测）</label><input id="imageSelector" placeholder="例如 img"><button class="action secondary" id="pickImage">选取图片</button>
          <label>上传按钮 CSS 选择器（可选）</label><input id="uploadButtonSelector" placeholder="上传入口按钮选择器"><button class="action secondary" id="pickUploadButton">选取上传按钮</button>
          <label>文件输入控件 CSS 选择器（Flow/千问优先拖放，无需设置）</label><input id="fileInputSelector" placeholder="其他平台可选：input[type=file]"><button class="action secondary" id="pickFileInput">选取文件输入控件</button>
        </div>
        <div class="section"><div class="section-title">全平台共用任务设置</div>
          <div class="row"><div><label>任务间隔最小秒数</label><input id="minDelay" type="number" min="1" value="12"></div><div><label>任务间隔最大秒数</label><input id="maxDelay" type="number" min="1" value="25"></div></div>
          <div class="row"><div><label>运行 N 条后休息（0=关闭）</label><input id="groupN" type="number" min="0" value="10"></div><div><label>休息最短秒数</label><input id="restMin" type="number" min="0" value="30"></div><div><label>休息最长秒数</label><input id="restMax" type="number" min="0" value="60"></div></div>
          <label>等待新图片最长时间（秒）</label><input id="imageTimeout" type="number" min="20" value="120">
          <label><input id="autoResume" type="checkbox" style="width:auto;vertical-align:middle"> 页面刷新后自动继续未完成任务</label>
          <label><input id="webDownloadEnabled" type="checkbox" style="width:auto;vertical-align:middle"> 启用扩展网页下载（关闭后不自动下载，也不执行页面图片下载）</label>
        </div>
        <div class="actions"><button class="action secondary" id="save">保存设置</button><button class="action" id="start">开始任务</button><button class="action pause" id="pause">暂停</button><button class="action stop" id="stop">停止</button><button class="action secondary" id="resumePending">恢复上次任务</button><button class="action secondary" id="download">下载当前页面图片</button></div>
        <div class="status" id="status">就绪。请先检查当前平台的文本框和发送按钮。</div>
        <div class="foot">Flow/千问优先使用网页拖放上传，无需选取会消失的文件输入控件。刷新恢复依赖本地 IndexedDB；刷新时正在生成的当前条目可能会重试一次。网页下载可在设置中关闭。</div>
      </div></section>`;
    document.documentElement.appendChild(hostEl);
    const $ = id => shadow.getElementById(id);
    statusEl = $("status");
    const panel = shadow.querySelector(".panel"), launcherWrap = shadow.querySelector(".launcher-wrap");
    const open = () => { panel.classList.add("open"); launcherWrap.style.display = "none"; };
    const close = () => { panel.classList.remove("open"); launcherWrap.style.display = "block"; };
    shadow.querySelector(".launcher").addEventListener("click", e => { if (draggedLauncher) { draggedLauncher = false; e.preventDefault(); return; } open(); });
    shadow.querySelector(".min").addEventListener("click", close);
    shadow.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", async () => { await saveCurrentPlatform(); activePlatform = btn.dataset.platform; await loadPlatform(); }));

    async function saveCurrentPlatform() {
      await updatePlatformSettings(activePlatform, { inputSelector: $("inputSelector").value.trim(), sendSelector: $("sendSelector").value.trim(), imageSelector: $("imageSelector").value.trim(), uploadButtonSelector: $("uploadButtonSelector").value.trim(), fileInputSelector: $("fileInputSelector").value.trim() });
      const shared = {}; ["minDelay", "maxDelay", "groupN", "restMin", "restMax", "imageTimeout"].forEach(k => shared[k] = Math.max(0, Number($(k).value) || 0));
      await chrome.storage.local.set({ sharedSettings: shared, autoResume: $("autoResume").checked, webDownloadEnabled: $("webDownloadEnabled").checked });
    }
    async function loadPlatform() {
      const cfg = await getPlatformSettings(activePlatform);
      $("inputSelector").value = cfg.inputSelector || ""; $("sendSelector").value = cfg.sendSelector || ""; $("imageSelector").value = cfg.imageSelector || ""; $("uploadButtonSelector").value = cfg.uploadButtonSelector || ""; $("fileInputSelector").value = cfg.fileInputSelector || "";
      shadow.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.platform === activePlatform));
      $("platformNote").textContent = activePlatform === currentPlatform ? `当前网页：${PLATFORMS[activePlatform].label}（可执行任务；平台选择器需单独验证）` : `正在编辑 ${PLATFORMS[activePlatform].label} 的独立设置；当前网页是 ${PLATFORMS[currentPlatform].label}，请切换到对应网站后执行任务。`;
    }
    async function loadAll() {
      const s = await chrome.storage.local.get(["sharedSettings", "lastStatus", "floatingPosition", "prompts", "imagePrompt", "autoResume", "webDownloadEnabled"]);
      const g = s.sharedSettings || {};
      for (const [k, def] of Object.entries({ minDelay: 12, maxDelay: 25, groupN: 10, restMin: 30, restMax: 60, imageTimeout: 120 })) $(k).value = g[k] ?? def;
      if (s.prompts) $("prompts").value = s.prompts; if (s.imagePrompt) $("imagePrompt").value = s.imagePrompt;
      $("autoResume").checked = s.autoResume === true; $("webDownloadEnabled").checked = s.webDownloadEnabled === true; $("download").disabled = !$("webDownloadEnabled").checked;
      if (s.lastStatus) status("上次状态：" + s.lastStatus);
      if (s.floatingPosition) { hostEl.style.left = `${s.floatingPosition.left}px`; hostEl.style.top = `${s.floatingPosition.top}px`; hostEl.style.right = "auto"; hostEl.style.bottom = "auto"; }
      await loadPlatform();
      const pending = await readPending();
      if (pending && pending.platform === currentPlatform && pending.completed < (pending.tasks || []).length) {
        const resume = async () => {
          const settings = await chrome.storage.local.get(["autoResume", "sharedSettings"]);
          if (settings.autoResume !== true) { status(`检测到未完成任务：${pending.completed}/${pending.tasks.length}。可点击“恢复上次任务”，或开启自动继续。`); return; }
          status(`正在恢复任务队列：从第 ${pending.completed + 1}/${pending.tasks.length} 条继续……`);
          if (pending.kind === "text") runBatch(pending.tasks, pending.cfg || await getPlatformSettings(currentPlatform), pending.shared || settings.sharedSettings || {}, pending.completed, true);
          else runImageBatch(pending.tasks, pending.cfg || await getPlatformSettings(currentPlatform), pending.shared || settings.sharedSettings || {}, pending.completed, true);
        };
        setTimeout(resume, 900);
      }
    }
    $("save").addEventListener("click", async () => { await saveCurrentPlatform(); await chrome.storage.local.set({ prompts: $("prompts").value, imagePrompt: $("imagePrompt").value }); $("download").disabled = !$("webDownloadEnabled").checked; status("当前平台设置和全局设置已保存。"); });
    $("webDownloadEnabled").addEventListener("change", async () => { $("download").disabled = !$("webDownloadEnabled").checked; await chrome.storage.local.set({ webDownloadEnabled: $("webDownloadEnabled").checked }); });
    $("autoResume").addEventListener("change", async () => { await chrome.storage.local.set({ autoResume: $("autoResume").checked }); });
    $("resumePending").addEventListener("click", async () => {
      const pending = await readPending();
      if (!pending || pending.platform !== currentPlatform) { status("当前网页没有可恢复的任务，或任务属于其他平台页面。"); return; }
      const settings = await chrome.storage.local.get("sharedSettings");
      if (pending.kind === "text") runBatch(pending.tasks, pending.cfg || await getPlatformSettings(currentPlatform), pending.shared || settings.sharedSettings || {}, pending.completed || 0, true);
      else runImageBatch(pending.tasks, pending.cfg || await getPlatformSettings(currentPlatform), pending.shared || settings.sharedSettings || {}, pending.completed || 0, true);
    });
    $("start").addEventListener("click", async () => {
      if (activePlatform !== currentPlatform) { status(`当前网页是 ${PLATFORMS[currentPlatform].label}，不能执行 ${PLATFORMS[activePlatform].label} 任务。请切换到对应网站。`); return; }
      await saveCurrentPlatform(); await chrome.storage.local.set({ prompts: $("prompts").value });
      const cfg = await getPlatformSettings(currentPlatform), all = await chrome.storage.local.get("sharedSettings");
      if(taskMode==='text') { const prompts = $("prompts").value.split(/[|\n\r]+/).map(x => x.trim()).filter(Boolean); runBatch(prompts, cfg, all.sharedSettings || {}); }
      else if(taskMode==='simple') { if(!selectedImageFiles.length){status('请先选择或拖入参考图片。');return;} const prompt=$('imagePrompt').value.trim(); if(!prompt){status('请先输入统一图生图提示词。');return;} runImageBatch(selectedImageFiles.map(file=>({file,prompt})),cfg,all.sharedSettings||{}); }
      else { try { const tasks=buildAdvancedTasks(); if(!tasks.length)throw new Error('没有可执行的表格任务，请检查 A、B 列。'); runImageBatch(tasks,cfg,all.sharedSettings||{}); } catch(err){status('高级图生图无法启动：'+err.message);} }
    });
    $("pause").addEventListener("click", () => { if (!running) { status("当前没有运行中的任务。"); return; } paused = !paused; $("pause").textContent = paused ? "恢复任务" : "暂停"; status(paused ? "已暂停。当前网站生成不会被强制取消。" : "已恢复，继续执行队列。"); progress(); });
    $("stop").addEventListener("click", () => { if (!running) { status("当前没有运行中的任务。"); return; } stopRequested = true; paused = false; status("已请求停止，当前步骤结束后退出队列。"); progress(); });
    $("pickInput").addEventListener("click", () => pickElement("inputSelector"));
    $("pickSend").addEventListener("click", () => pickElement("sendSelector"));
    $("pickImage").addEventListener("click", () => pickElement("imageSelector"));
    $("pickUploadButton").addEventListener("click", () => pickElement("uploadButtonSelector"));
    $("pickFileInput").addEventListener("click", () => pickElement("fileInputSelector"));
    $("download").addEventListener("click", async () => {
      if ((await chrome.storage.local.get("webDownloadEnabled")).webDownloadEnabled !== true) { status("网页下载功能已关闭。可在全局任务设置中启用。后续可由本地 EXE 下载器统一接管。"); return; }
      const imgs = imageSources((await getPlatformSettings(currentPlatform)).imageSelector);
      if (!imgs.length) { status("没有找到可下载的页面图片（目前仅支持可访问的 HTTP/HTTPS 图片地址）。"); return; }
      for (let i = 0; i < imgs.length; i++) await askBackground("DOWNLOAD_IMAGE", { url: imgs[i].url, filename: `page-image-${Date.now()}-${i + 1}.png`, platform: PLATFORMS[currentPlatform].folder, extension: "" });
      status(`已提交 ${imgs.length} 张页面图片的下载请求。`);
    });
    $("file").addEventListener("change", async e => {
      const f = e.target.files?.[0]; if (!f) return;
      try {
        let rows;
        if (f.name.toLowerCase().endsWith(".txt")) rows = (await f.text()).split(/\r?\n/).map(x => x.trim()).filter(Boolean);
        else rows = (await window.AIBA_IMPORT.readXlsxFirstSheet(await f.arrayBuffer())).map(r=>r.A).filter(Boolean);
        $("prompts").value = rows.join("\n"); await chrome.storage.local.set({ prompts: $("prompts").value }); status(`已导入 ${rows.length} 条提示词。`);
      } catch (err) { status("导入失败：" + err.message); }
      e.target.value = "";
    });
    async function readXlsxFirstColumn(buf) {
      const u8 = new Uint8Array(buf), dv = new DataView(buf); let eocd = -1;
      for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
      if (eocd < 0) throw new Error("文件不是有效的 XLSX 压缩包");
      const count = dv.getUint16(eocd + 10, true), cdOff = dv.getUint32(eocd + 16, true), entries = {}; let p = cdOff;
      for (let n = 0; n < count; n++) { if (dv.getUint32(p, true) !== 0x02014b50) break; const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lh = dv.getUint32(p + 42, true); const name = new TextDecoder().decode(u8.slice(p + 46, p + 46 + nl)); entries[name] = { method, csize, lh }; p += 46 + nl + el + cl; }
      async function entry(name) { const x = entries[name]; if (!x) return null; const q = x.lh, nl = dv.getUint16(q + 26, true), el = dv.getUint16(q + 28, true), comp = u8.slice(q + 30 + nl + el, q + 30 + nl + el + x.csize); if (x.method === 0) return new TextDecoder().decode(comp); if (x.method !== 8) throw new Error("不支持的 XLSX 压缩格式"); return await new Response(new Blob([comp]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).text(); }
      const ss = await entry("xl/sharedStrings.xml"); let shared = []; if (ss) shared = [...new DOMParser().parseFromString(ss, "application/xml").getElementsByTagName("si")].map(si => [...si.getElementsByTagName("t")].map(t => t.textContent).join(""));
      const sn = Object.keys(entries).filter(n => /^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort()[0]; if (!sn) throw new Error("找不到工作表");
      const xml = new DOMParser().parseFromString(await entry(sn), "application/xml");
      return [...xml.getElementsByTagName("row")].map(row => { const c = [...row.getElementsByTagName("c")].find(c => /^A\d+$/.test(c.getAttribute("r") || "")); if (!c) return ""; const v = c.getElementsByTagName("v")[0]?.textContent ?? ""; return c.getAttribute("t") === "s" ? (shared[Number(v)] || "").trim() : (c.getElementsByTagName("is")[0]?.textContent || v).trim(); }).filter(Boolean);
    }
    shadow.querySelectorAll('[data-mode]').forEach(btn=>btn.addEventListener('click',()=>{
      taskMode=btn.dataset.mode; shadow.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('active',x===btn));
      $('textMode').style.display=taskMode==='text'?'block':'none'; $('imageMode').style.display=taskMode==='simple'?'block':'none'; $('advancedMode').style.display=taskMode==='advanced'?'block':'none';
      $('modeNote').textContent=taskMode==='text'?'文生图：每行一条提示词，支持 | 分隔。':taskMode==='simple'?'简易图生图：多张图片共用同一句提示词，逐张上传、生成。':'高级图生图：Excel A 列路径、B 列专属提示词；需要同时选择对应图片文件。';
    }));
    const updateImageCount=()=>{$('imageCount').textContent=`已选择 ${selectedImageFiles.length} 张图片`;};
    $('imageFiles').addEventListener('change',e=>{selectedImageFiles=[...(e.target.files||[])];updateImageCount();});
    const dz=$('dropzone');
    ['dragenter','dragover'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('drag');}));
    ['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('drag');}));
    dz.addEventListener('drop',e=>{selectedImageFiles=[...(e.dataTransfer?.files||[])].filter(f=>f.type.startsWith('image/'));updateImageCount();});
    $('advancedXlsx').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{advancedRows=(await window.AIBA_IMPORT.readXlsxFirstSheet(await f.arrayBuffer())).filter(r=>r.A&&r.B);$('advancedNote').textContent=`已读取 ${advancedRows.length} 条有效任务。请再选择对应图片文件，系统将按文件名匹配。`;status(`高级图生图表格已导入：${advancedRows.length} 行。`);}catch(err){status('高级表格读取失败：'+err.message);}e.target.value='';});
    $('advancedFiles').addEventListener('change',e=>{selectedImageFiles=[...(e.target.files||[])].filter(f=>f.type.startsWith('image/'));$('advancedNote').textContent+=` 已授权选择 ${selectedImageFiles.length} 张图片。`;});
    function buildAdvancedTasks(){const map=new Map(selectedImageFiles.map(f=>[f.name.toLowerCase(),f]));const tasks=[],missing=[];for(const row of advancedRows){const key=window.AIBA_IMPORT.basename(row.A),file=map.get(key);if(file)tasks.push({file,prompt:row.B,row:row.row});else missing.push(`${row.row}:${row.A}`);}if(missing.length)throw new Error(`有 ${missing.length} 行未匹配到图片文件：${missing.slice(0,5).join('；')}`);return tasks;}

    // Drag launcher or panel header; persist its position.
    let drag = null;
    const beginDrag = (e, target) => { if (e.button !== 0 || e.target.closest("button") && target === "panel") return; const r = hostEl.getBoundingClientRect(); drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, startX: e.clientX, startY: e.clientY, target }; draggedLauncher = false; if (target === "panel") e.preventDefault(); };
    launcherWrap.addEventListener("pointerdown", e => beginDrag(e, "launcher"));
    shadow.querySelector(".head").addEventListener("pointerdown", e => beginDrag(e, "panel"));
    document.addEventListener("pointermove", e => { if (!drag) return; if (Math.abs(e.clientX-drag.startX)+Math.abs(e.clientY-drag.startY)>5 && drag.target === "launcher") draggedLauncher = true; const left = Math.max(0, Math.min(innerWidth - 70, e.clientX - drag.dx)); const top = Math.max(0, Math.min(innerHeight - 70, e.clientY - drag.dy)); hostEl.style.left = `${left}px`; hostEl.style.top = `${top}px`; hostEl.style.right = "auto"; hostEl.style.bottom = "auto"; });
    document.addEventListener("pointerup", async () => { if (!drag) return; drag = null; const r = hostEl.getBoundingClientRect(); await chrome.storage.local.set({ floatingPosition: { left: r.left, top: r.top } }); });
    shadow.addEventListener("click", e => e.stopPropagation());
    loadAll();
  }

  createPanel();
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "OPEN_FLOATING_PANEL" && shadow) { shadow.querySelector(".panel").classList.add("open"); shadow.querySelector(".launcher-wrap").style.display = "none"; sendResponse({ message: "悬浮面板已打开" }); }
    if (msg.type === "DOWNLOAD_RESULT") { status(msg.ok ? `下载已加入队列：${msg.filename}` : `下载失败：${msg.error}`); }
    return true;
  });
})();
